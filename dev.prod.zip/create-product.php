



<html>
<head>

</head>
<body>



<form method="POST" action="responce.php">
    <br />
    <input class="form-control" type="text" class="input" name="materialnumber" placeholder="Material Number" /><br />
    <input class="form-control" type="text" class="input" name="productname" placeholder="Product Name" /><br />
    <input class="form-control" type="text" class="input" name="chk" placeholder="Check..." /><br />
    <input class="form-control" type="text" class="input" name="qty" placeholder="Qty..." /><br />
    <input class="form-control" type="text" class="input" name="free" placeholder="Free Count" /><br />
    <input class="form-control" type="text" class="input" name="price" placeholder="$ Price" /><br />
    <input class="form-control" type="text" class="input" name="sku" placeholder="SKU..." /><br />
    <input class="btn btn-primary" type="submit" value="Add Product" name="createproduct"/>
    </form>

</body>

</html>