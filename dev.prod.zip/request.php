<html>
<head>

</head>
<body>



<form method="POST" action="responce.php">
    <br />
    <input class="form-control" type="text" class="input" name="salemanname" placeholder="Saleman Full Name..." /><br />
    <input class="form-control" type="text" class="input" name="salemanid" placeholder="Saleman ID#" /><br />
    <input class="form-control" type="text" class="input" name="dep" placeholder="Department..." /><br />
    <input class="form-control" type="text" class="input" name="jtitle" placeholder="Jop Title..." /><br />
    <input class="form-control" type="email" class="input" name="email" placeholder="example@sunbulahgroup.com" /><br />
    <input class="form-control" type="text" class="input" name="phonenumber" placeholder="05xxxxxxxx" /><br />
    <input class="form-control" type="password" class="input" name="pass" placeholder="Password..." /><br />
    <input class="btn btn-primary" type="submit" value="Register" name="registerbutton"/>
    </form>

</body>

</html>